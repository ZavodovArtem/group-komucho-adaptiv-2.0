const minus = document.querySelector('[data-action = "minus"]');
const plus = document.querySelector('[data-action = "plus"]');
const counter = document.querySelector('[data-counter]')


// minus.addEventListener('click', function() {
//     console.log('minus click');

//     // if (parseInt)

//     if (parseInt (counter.innerText) > 1) {
//         counter.innerText = --counter.innerText;
//     }

// })

// plus.addEventListener('click', function () {
//     console.log('plus click');
//     counter.innerText = ++counter.innerText;
// })





